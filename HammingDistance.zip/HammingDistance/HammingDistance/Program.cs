﻿using System;

namespace HammingDistance
{
    class Program
    {
        static void Main(string[] args)
        {
            int distance = HammingDistance(1, 4);

            Console.ReadLine();
        }

        private static int HammingDistance(int x, int y)
        {
            int distance = 0;

            while (x > 0 && y > 0)
            {
                if (x % 2 != y % 2)
                    distance++;
                x = x / 2;
                y = y / 2;
            }

            distance += TotalBits(x == 0 ? y : x);

            return distance;
        }

        private static int TotalBits(int value)
        {
            int bits = 0;
            while (value > 0)
            {
                bits += value%2;
                value /= 2;
            }

            return bits;
        }
    }
}
